# The Recursive Attention Framework: ADHD as Quantum Attentional Resonance

## An Expanded Theoretical Analysis

### Abstract

This expanded theoretical framework provides a comprehensive analysis of Attention Deficit Hyperactivity Disorder (ADHD) reconceptualized as a distinct cognitive processing system characterized by recursive attentional patterns that follow principles of resonance rather than normative hierarchies of importance. Drawing from interdisciplinary research across cognitive neuroscience, quantum cognition theory, network dynamics, and dynamical systems theory, this framework presents substantive evidence for understanding ADHD as "recursive attention" operating in states analogous to quantum superposition. This perspective explains numerous ADHD phenomena including hyperfocus, apparent distractibility, interest-based nervous systems, and time inconsistency. This paper extends the original theoretical propositions with additional neurobiological mechanisms, mathematical formulations, and empirical validation pathways, ultimately proposing that ADHD represents a fundamentally different—rather than deficient—attentional architecture with distinct processing advantages and challenges.

## 1. Introduction: Paradigm Shift in ADHD Conceptualization

### 1.1 Historical Context and Limitations of Deficit Models

The historical conceptualization of ADHD has predominantly focused on deficits, with the disorder's very nomenclature emphasizing a lack of attentional capacity. This deficit-focused perspective originated in early clinical observations (Still, 1902) and was formalized in successive editions of the Diagnostic and Statistical Manual of Mental Disorders, evolving from "minimal brain dysfunction" to the current ADHD classification (American Psychiatric Association, 2013).

However, this deficit framework fails to account for several well-documented ADHD phenomena:

1. **Hyperfocus paradox**: The ability to maintain intense, sustained attention on high-interest activities despite apparent difficulties with attention in other contexts (Ashinoff & Abu-Akel, 2021; Hupfeld et al., 2018)

2. **Inconsistent performance**: Highly variable task performance that fluctuates based on context, interest, and motivational factors (Kofler et al., 2013)

3. **Interest-based nervous system**: Enhanced performance and attention specifically for stimuli with intrinsic motivational value (Volkow et al., 2011; Sedgwick et al., 2019)

4. **Creative advantages**: Overrepresentation of ADHD in creative professions and enhanced divergent thinking abilities (White & Shah, 2006; Hoogman et al., 2020)

These phenomena suggest that ADHD represents a qualitatively different attention system rather than merely a deficient one—a perspective increasingly supported by neuroimaging and cognitive research (Castellanos & Proal, 2012; Szekely et al., 2021).

### 1.2 Core Thesis: ADHD as Recursive Attention

This paper proposes that ADHD can be more accurately understood as a distinct form of attentional organization characterized by:

1. **Recursivity**: Attention that follows self-referential patterns creating complex, non-linear trajectories
2. **Resonance-based processing**: Prioritization of stimuli based on their resonant properties rather than objective importance
3. **Superposition-like attentional states**: Simultaneous engagement with multiple stimuli until "collapsed" by sufficient resonance

The "Recursive Attention Framework" posits that these characteristics emerge from fundamental differences in neural connectivity, oscillatory dynamics, and neurochemical function, creating an attentional system that operates according to different organizational principles than neurotypical attention.

## 2. Theoretical Foundations: Interdisciplinary Integration

### 2.1 Recursion in Cognitive Systems

#### 2.1.1 Mathematical Foundations of Recursion

Recursion refers to a process that calls itself, creating self-referential patterns that can generate complex outputs from simple rules. Mathematically, recursion can be expressed as:

$$f(n) = g(n, f(n-1))$$

Where the function $f$ at iteration $n$ depends on both the current input and the function's previous output. This creates nested, self-referential structures that can exhibit emergent complexity (Hofstadter, 1979; Corballis, 2011).

In cognitive systems, recursion appears in multiple domains:

- **Linguistic recursion**: The embedding of phrases within phrases of the same type (Chomsky, 1957; Hauser et al., 2002)
- **Theory of mind**: Recursive mental state attributions ("I think that you believe that she knows...") (Premack & Woodruff, 1978)
- **Hierarchical action planning**: Complex action sequences comprised of nested sub-goals (Koechlin et al., 2003)

These recursive cognitive processes typically rely on hierarchical control structures in the prefrontal cortex (Badre & D'Esposito, 2009).

#### 2.1.2 Recursion in ADHD Attention

The Recursive Attention Framework proposes that attention in ADHD operates through recursive processes that differ from typical hierarchical control. While neurotypical attention follows relatively linear pathways with priorities established through top-down prefrontal control (Miller & Cohen, 2001), ADHD attention exhibits patterns consistent with altered recursive dynamics:

1. **Self-reinforcing attentional loops**: Attention recursively returns to stimuli with high resonance value, creating persistent engagement patterns

2. **Fractal-like attentional trajectories**: Attention shifting that displays self-similarity across different time scales

3. **Emergent rather than planned focus**: Attentional states that emerge from recursive interaction between stimulus properties and internal resonance rather than explicit top-down control

Evidence for altered recursive processes in ADHD includes:

- Reduced hierarchical organization in prefrontal-striatal networks (Norman et al., 2016)
- Altered connectivity between default mode and task-positive networks (Castellanos et al., 2008)
- Increased temporal variability in attention network activation (Skirrow et al., 2015)

These findings suggest that ADHD involves fundamental differences in how recursive cognitive processes are implemented, particularly in attentional systems.

### 2.2 Quantum Cognition Theory

#### 2.2.1 Quantum Probability in Cognitive Science

Quantum cognition theory applies mathematical principles from quantum mechanics to cognitive phenomena without claiming quantum effects in neural tissue (Busemeyer & Bruza, 2012; Pothos & Busemeyer, 2013). This approach has successfully modeled several cognitive phenomena that classical probability theory struggles to explain:

- Order effects in judgment and decision making (Trueblood & Busemeyer, 2011)
- Violations of the sure-thing principle (Pothos & Busemeyer, 2009)
- Contextual effects in perception and categorization (Blutner et al., 2013)

Of particular relevance to attention is the concept of superposition, wherein a quantum system exists in multiple states simultaneously until measured or observed.

#### 2.2.2 Quantum Models of Attention

Wang et al. (2018) proposed that attention itself can be modeled using quantum probability theory, with attentional states existing in superposition until "collapsed" by cognitive measurement. In this model, attention is represented as a state vector in a Hilbert space, with stimuli represented as basis vectors.

The attentional state vector $|\psi\rangle$ can be expressed as a linear combination of basis states:

$$|\psi\rangle = \sum_{i} c_i |s_i\rangle$$

Where $|s_i\rangle$ represents attention to stimulus $i$, and $c_i$ represents the complex probability amplitude associated with that stimulus. The probability of attention being allocated to stimulus $i$ upon measurement is given by $|c_i|^2$.

This quantum attention model predicts several phenomena observed in human attention:

1. **Contextual dependencies**: The probability of attending to a stimulus depends on the full context of available stimuli
2. **Interference effects**: Interactions between stimuli that cannot be explained by classical probability
3. **Measurement-induced state changes**: The act of attending to one stimulus changes the probability distribution for subsequent attentional allocation

#### 2.2.3 Quantum Attention in ADHD

The Recursive Attention Framework proposes that ADHD attention exhibits more pronounced quantum-like properties than neurotypical attention:

1. **Extended superposition**: Attention remains in superposition-like states for longer periods, with multiple stimuli simultaneously active in consciousness

2. **Resonance-weighted probability amplitudes**: The probability amplitudes ($c_i$) are more strongly influenced by resonance factors than by conventional importance

3. **Reduced measurement-induced collapse**: Greater resistance to complete attentional collapse onto a single stimulus unless highly resonant

Evidence supporting quantum-like attention in ADHD includes:

- Greater susceptibility to contextual effects in attention tasks (Roberts et al., 2017)
- More distributed patterns of neural activation during attention tasks (Cortese et al., 2012)
- Subjective reports of simultaneous awareness of multiple stimuli (Brown, 2005)

These observations suggest that ADHD attention may operate more prominently in superposition-like states, with full attentional collapse requiring stronger resonance than in neurotypical individuals.

### 2.3 Resonance in Neural Systems

#### 2.3.1 Neural Resonance Mechanisms

Neural resonance occurs when oscillatory brain networks synchronize in response to stimuli that match their intrinsic frequencies or properties (Engel et al., 2001; Fries, 2015). This resonance facilitates information processing through several mechanisms:

1. **Phase synchronization**: Alignment of oscillatory phases between neural populations that enhances communication efficiency
2. **Cross-frequency coupling**: Interactions between different frequency bands that enable hierarchical information processing
3. **Resonant frequency entrainment**: Adaptation of neural oscillations to match stimulus properties

Neural resonance plays a crucial role in attention by enhancing processing of selected stimuli through synchronized oscillatory activity (Lakatos et al., 2008; Schroeder & Lakatos, 2009).

#### 2.3.2 Altered Resonance Dynamics in ADHD

Research has identified several differences in oscillatory patterns and resonance mechanisms in individuals with ADHD:

1. **Altered theta-gamma coupling**: Reduced cross-frequency coupling between theta (4-8 Hz) and gamma (30-100 Hz) oscillations during attentional tasks (Lenartowicz et al., 2018)

2. **Decreased alpha phase coherence**: Lower stability in alpha band (8-12 Hz) synchronization during sustained attention (Mazaheri et al., 2014)

3. **Increased theta power**: Elevated theta oscillations, particularly in frontal regions (Loo & Makeig, 2012)

These alterations suggest fundamentally different resonance properties in ADHD neural systems, potentially explaining the distinct patterns of attentional allocation observed in this population.

#### 2.3.3 Dopaminergic Mechanisms of Resonance

The dopamine system plays a critical role in establishing neural resonance, particularly for stimuli with motivational significance. The Dopamine Value Transfer Mechanism (DVTM) proposed by Volkow et al. (2011) suggests that dopamine mediates the assignment of value to stimuli based on associated reward experiences.

In ADHD, alterations in dopaminergic function create a neurochemical basis for resonance-based attention:

1. **Altered reward sensitivity**: Enhanced dopaminergic response to novel and intrinsically rewarding stimuli (Plichta & Scheres, 2014)

2. **Reduced tonic dopamine**: Lower baseline dopamine levels that may increase the contrast between high-interest and low-interest stimuli (Volkow et al., 2009)

3. **Increased dopamine transporter density**: Faster dopamine reuptake that may intensify the contrast between resonant and non-resonant stimuli (Spencer et al., 2013)

These dopaminergic alterations create neurochemical conditions that favor strong attentional resonance for certain stimuli while potentially impairing sustained attention to non-resonant stimuli.

## 3. The Recursive Attention Framework: Extended Propositions

### 3.1 Proposition 1: Quantum Superposition in ADHD Attention

#### 3.1.1 Theoretical Formulation

In individuals with ADHD, attention exists in a state analogous to quantum superposition, simultaneously engaging with multiple stimuli with probability amplitudes determined by resonant properties. This can be represented as:

$$|\psi_{ADHD}\rangle = \sum_{i} r_i|s_i\rangle$$

Where $r_i$ represents the resonance amplitude for stimulus $i$, which is determined by the stimulus's novelty, interest value, challenge level, urgency, and emotional salience.

This contrasts with neurotypical attention, which more readily "collapses" into singular focus based on objective importance hierarchies:

$$|\psi_{NT}\rangle \rightarrow |s_j\rangle$$

Where $s_j$ represents the objectively most important stimulus as determined by top-down control processes.

#### 3.1.2 Empirical Evidence

Several lines of evidence support this proposition:

1. **Broadened attentional scope**: Studies using attentional blink paradigms show that individuals with ADHD often perceive more secondary stimuli than controls, suggesting broader attentional distribution (Grossman et al., 2015)

2. **Simultaneous stimulus awareness**: Self-reports from individuals with ADHD frequently describe awareness of multiple stimuli simultaneously (Brown, 2005; Hallowell & Ratey, 2011)

3. **Reduced inattentional blindness**: Some studies suggest ADHD is associated with lower rates of inattentional blindness, consistent with attention distributed across more elements in a scene (Kreither et al., 2017)

4. **Higher distractibility by peripheral stimuli**: Greater awareness of and response to peripheral stimuli during focused tasks (Forster et al., 2014)

These findings suggest that ADHD attention operates in a more distributed state, consistent with the superposition analogy proposed in the framework.

#### 3.1.3 Neurobiological Substrates

The neurobiological basis for this superposition-like attentional state likely involves:

1. **Altered default mode network (DMN) regulation**: Less separation between DMN and task-positive networks, allowing simultaneous activation (Mowinckel et al., 2017)

2. **Reduced alpha suppression**: Deficits in using alpha oscillations to inhibit processing of irrelevant stimuli (Mazaheri et al., 2010)

3. **Broader cortical activation patterns**: More distributed neural activation during attention tasks (Cortese et al., 2012)

These neural patterns create conditions that support the maintenance of multiple simultaneous attentional foci rather than exclusive focus on a single stimulus.

### 3.2 Proposition 2: Recursive Attention Patterns

#### 3.2.1 Theoretical Formulation

Attention in ADHD follows recursive patterns determined by resonance rather than linear hierarchies. This recursion can be modeled as:

$$A(t+1) = f(A(t), R(t))$$

Where $A(t)$ represents the attentional state at time $t$, $R(t)$ represents the resonance values of available stimuli at time $t$, and $f$ is a recursive function that maps current attentional states and resonance values to subsequent attentional states.

This recursive function creates self-reinforcing loops that continually re-evaluate stimuli based on their resonant qualities rather than following predetermined sequences of importance.

#### 3.2.2 Empirical Evidence

Evidence for recursive attention patterns in ADHD includes:

1. **Fractal patterns in response time variability**: ADHD performance shows self-similar patterns of variability across different time scales, consistent with recursive processes (Castellanos et al., 2005)

2. **Cyclical patterns of attention**: Fluctuations in attentional performance that follow predictable cycles rather than random variation (Sonuga-Barke & Castellanos, 2007)

3. **Association chains in thought processes**: Self-reported tendency for thoughts to follow associative chains based on resonance rather than hierarchical importance (Delisle & Delisle, 2014)

4. **Perseverative thought patterns**: Tendency for attention to recursively return to high-interest topics or concerns (Watkins, 2008)

These patterns suggest that ADHD attention follows complex recursive trajectories governed by internal resonance dynamics rather than external task demands.

#### 3.2.3 Neurobiological Substrates

The neural basis for recursive attention likely involves:

1. **Altered prefrontal-striatal loops**: Changes in the feedback circuits that typically regulate attention (Norman et al., 2016)

2. **Reduced top-down control**: Decreased ability of prefrontal regions to impose hierarchical structure on attentional processes (Arnsten & Rubia, 2012)

3. **Dynamic changes in network coupling**: More variable coupling between neural networks that process different aspects of attention (Sidlauskaite et al., 2016)

These alterations create neural conditions that favor recursive processing patterns over hierarchically structured attention.

### 3.3 Proposition 3: Resonance Factors in ADHD

#### 3.3.1 Theoretical Formulation

The resonant properties that drive recursive attention in ADHD can be formalized as a resonance function:

$$R(s_i) = w_N N(s_i) + w_I I(s_i) + w_C C(s_i) + w_U U(s_i) + w_E E(s_i)$$

Where:

- $N(s_i)$ = Novelty value of stimulus $i$
- $I(s_i)$ = Interest alignment of stimulus $i$
- $C(s_i)$ = Challenge optimization of stimulus $i$
- $U(s_i)$ = Urgency/temporal pressure of stimulus $i$
- $E(s_i)$ = Emotional salience of stimulus $i$
- $w_X$ = Individual-specific weighting factors for each resonance component

This resonance function determines the probability amplitudes in the quantum attention model and drives the recursive attentional patterns described in Proposition 2.

#### 3.3.2 Empirical Evidence

Research supports the influence of these resonance factors on ADHD attention:

1. **Novelty effects**: Enhanced performance and attention for novel stimuli and environments (Hoogman et al., 2017)

2. **Interest-based performance**: Dramatic improvements in attention, working memory, and executive function when tasks align with personal interests (Sedgwick et al., 2019)

3. **Challenge optimization**: Improved performance under optimal challenge conditions that avoid both boredom and overwhelm (Sikström & Söderlund, 2007)

4. **Urgency effects**: Enhanced performance under deadline pressure or other temporal constraints (Haenlein & Caul, 1987)

5. **Emotional salience**: Stronger attentional capture by emotionally relevant stimuli (Shaw et al., 2014)

These factors consistently modulate attention and performance in ADHD, supporting their role as key determinants of attentional resonance.

#### 3.3.3 Neurobiological Substrates

The neurobiological mechanisms underlying these resonance factors include:

1. **Novelty processing**: Enhanced activity in the ventral striatum and substantia nigra/ventral tegmental area in response to novel stimuli (Bunzeck & Düzel, 2006)

2. **Interest-based motivation**: Increased activation in reward circuitry during high-interest tasks (Liddle et al., 2011)

3. **Optimal arousal**: Inverted-U relationship between noradrenergic/dopaminergic activity and performance (Aston-Jones & Cohen, 2005)

4. **Temporal processing**: Altered striatal and cerebellar activation during time-constrained tasks (Rubia et al., 2009)

5. **Emotional processing**: Enhanced amygdala activation in response to emotional stimuli (Posner et al., 2011)

These neural mechanisms create a biological foundation for the resonance-based attention characteristic of ADHD.

### 3.4 Proposition 4: Hyperfocus as Attentional Resonance Stability

#### 3.4.1 Theoretical Formulation

Hyperfocus represents a special case of recursive attention where a stimulus or activity creates such strong resonance that the recursive attention loop achieves temporary stability, similar to a standing wave in physics. Mathematically, this occurs when:

$$R(s_i) > \theta_{stability}$$

Where $\theta_{stability}$ represents a threshold value above which attentional recursion becomes stable rather than chaotic. When this threshold is exceeded, the attentional state vector collapses to a highly stable focus:

$$|\psi_{ADHD}\rangle \rightarrow |s_i\rangle \ \text{when} \ R(s_i) > \theta_{stability}$$

This explains why individuals with ADHD can maintain intense focus on high-interest activities despite apparent difficulties with sustained attention in other contexts.

#### 3.4.2 Empirical Evidence

Evidence supporting this conceptualization of hyperfocus includes:

1. **Task-specific sustained attention**: Studies showing that sustained attention deficits in ADHD are context-dependent rather than universal (Dekkers et al., 2017)

2. **Flow state frequency**: Higher reported frequency of flow states in ADHD during engaging activities (Hupfeld et al., 2018)

3. **Neuroimaging during engagement**: Increased activation in attention and reward networks during engaging tasks (Liddle et al., 2011)

4. **Time perception alterations**: Reports of altered time perception during hyperfocus, consistent with attentional stability (Shaffer et al., 2001)

These findings suggest that hyperfocus represents a distinct attentional state that emerges when activities meet specific resonance criteria.

#### 3.4.3 Neurobiological Substrates

The neurobiological basis for hyperfocus likely involves:

1. **Enhanced reward circuit activation**: Sustained dopaminergic signaling during high-interest activities (Volkow et al., 2011)

2. **Increased fronto-parietal network coherence**: Greater synchronization in attention networks during engaging tasks (Castellanos & Proal, 2012)

3. **Default mode network suppression**: Temporary normalization of DMN deactivation during highly engaging activities (Uddin et al., 2008)

These neural patterns create conditions for stable, sustained attention when activities generate sufficient resonance.

## 4. Extended Neurobiological Mechanisms

### 4.1 Default Mode Network Dynamics

#### 4.1.1 Default Mode Network in Neurotypical Attention

The default mode network (DMN) is a set of brain regions that show coordinated activity during rest and self-referential thought (Raichle et al., 2001). In neurotypical individuals, the DMN shows reciprocal relationships with task-positive networks:

1. **DMN deactivation during tasks**: Suppression of DMN activity during externally-oriented attention (Fox et al., 2005)
2. **Anti-correlated network dynamics**: Negative correlation between DMN and task-positive network activation (Fox et al., 2005)
3. **Controlled transitions**: Regulated switching between internally and externally directed attention (Spreng et al., 2010)

These dynamics support the hierarchical control of attention characteristic of neurotypical cognition.

#### 4.1.2 DMN Alterations in ADHD

Research has identified several alterations in DMN function in ADHD:

1. **Reduced task-related deactivation**: Failure to fully suppress DMN activity during attention tasks (Castellanos et al., 2008)

2. **Altered DMN connectivity**: Different patterns of functional connectivity within the DMN and between the DMN and other networks (Mowinckel et al., 2017)

3. **Temporal dysregulation**: Less consistent temporal anti-correlation between DMN and task-positive networks (Sripada et al., 2014)

4. **DMN interference**: Intrusion of DMN activity during tasks requiring sustained attention (Sonuga-Barke & Castellanos, 2007)

These alterations are consistent with the Recursive Attention Framework, as they create conditions where attention can simultaneously engage with both external tasks and internal processes—a state analogous to superposition.

#### 4.1.3 DMN and Recursive Attention

The altered DMN dynamics in ADHD directly support the recursive attention hypothesis:

1. **Simultaneous network activation**: Co-activation of normally anti-correlated networks enables attention to recursively shift between internal and external foci

2. **Self-referential processing during tasks**: Continued DMN activity during tasks facilitates the self-referential quality of recursive attention

3. **Variable network coupling**: Dynamic changes in network coupling create conditions for complex recursive patterns rather than stable attentional states

These DMN alterations provide a neurobiological basis for the quantum-like and recursive properties of attention proposed in this framework.

### 4.2 Dopaminergic and Noradrenergic Systems

#### 4.2.1 Catecholamine Function in Attention

Dopamine and norepinephrine play critical roles in attention regulation:

1. **Dopamine**: Mediates reward prediction, motivation, and the stability of frontostriatal circuits (Schultz, 2002)

2. **Norepinephrine**: Regulates arousal, stimulus salience, and the signal-to-noise ratio in sensory processing (Aston-Jones & Cohen, 2005)

Together, these neurotransmitters enable the selection and maintenance of attention based on both importance and motivational value.

#### 4.2.2 Catecholamine Alterations in ADHD

ADHD is associated with several catecholamine alterations:

1. **Dopamine transporter density**: Increased DAT density leading to faster dopamine clearance from synapses (Spencer et al., 2013)

2. **Dopamine receptor genetics**: Variations in dopamine receptor genes, particularly DRD4 and DRD5 (Li et al., 2014)

3. **Norepinephrine reuptake**: Altered norepinephrine transporter function affecting attentional regulation (Del Campo et al., 2011)

4. **Response to stimulants**: Normalization of attention with medications that increase synaptic catecholamines (Swanson et al., 2011)

These alterations create a neurochemical environment that favors attention to highly resonant stimuli while potentially impairing sustained attention to less resonant tasks.

#### 4.2.3 Catecholamines and Resonance-Based Attention

The dopaminergic and noradrenergic alterations in ADHD directly support the resonance-based attention hypothesis:

1. **Enhanced contrast**: Altered dopamine signaling may increase the contrast between high-interest and low-interest stimuli (Volkow et al., 2009)

2. **Reward-attention coupling**: Stronger coupling between reward circuits and attention networks, facilitating interest-based attention (Castellanos & Proal, 2012)

3. **Novelty sensitivity**: Enhanced dopaminergic response to novel stimuli, supporting novelty as a key resonance factor (Bunzeck & Düzel, 2006)

4. **Variable arousal regulation**: Altered noradrenergic function creating optimal arousal for certain tasks but suboptimal arousal for others (Aston-Jones & Cohen, 2005)

These neurochemical mechanisms provide a biological basis for the resonance factors identified in Proposition 3.

### 4.3 Oscillatory Synchronization and Information Processing

#### 4.3.1 Neural Oscillations in Attention

Neural oscillations coordinate information processing across brain regions through several mechanisms:

1. **Alpha oscillations (8-12 Hz)**: Inhibit processing in task-irrelevant regions through pulsed inhibition (Jensen & Mazaheri, 2010)

2. **Theta oscillations (4-8 Hz)**: Coordinate working memory and cognitive control processes (Cavanagh & Frank, 2014)

3. **Gamma oscillations (30-100 Hz)**: Enable precise temporal coding of stimulus information (Fries, 2009)

4. **Cross-frequency coupling**: Hierarchically organizes information processing across different timescales (Canolty & Knight, 2010)

These oscillatory mechanisms enable the selective enhancement of relevant information and suppression of irrelevant information characteristic of typical attention.

#### 4.3.2 Altered Oscillatory Patterns in ADHD

Research has identified several alterations in neural oscillations in ADHD:

1. **Elevated theta power**: Increased theta activity, particularly in frontal regions (Loo & Makeig, 2012)

2. **Reduced alpha modulation**: Deficits in using alpha oscillations to suppress irrelevant information (Mazaheri et al., 2010)

3. **Altered theta-gamma coupling**: Reduced coordination between theta and gamma oscillations during cognitive tasks (Lenartowicz et al., 2018)

4. **Increased intra-individual variability**: Greater moment-to-moment variability in oscillatory patterns (Kofler et al., 2013)

These oscillatory alterations create conditions for different information processing dynamics in ADHD.

#### 4.3.3 Oscillations and Quantum-Like Attention

The altered oscillatory patterns in ADHD support the quantum-like properties of attention proposed in this framework:

1. **Reduced inhibitory alpha**: Deficits in using alpha oscillations to suppress irrelevant information may support superposition-like states where multiple stimuli remain active in attention

2. **Variable phase synchronization**: Less stable phase relationships between brain regions may enable more complex recursive patterns of information flow

3. **Altered cross-frequency coupling**: Changes in the hierarchical organization of information processing may support resonance-based rather than importance-based attention

These oscillatory mechanisms provide a neurophysiological basis for the quantum-like and recursive properties of attention in ADHD.

## 5. Empirical Validation and Testing

### 5.1 Testable Predictions

The Recursive Attention Framework generates several testable predictions:

#### 5.1.1 Attentional Distribution Predictions

1. **Simultaneous stimulus awareness**: Individuals with ADHD will show greater awareness of secondary stimuli during primary task performance

2. **Resonance-modulated attention capture**: The probability of attention capture will correlate more strongly with resonance factors in ADHD than controls

3. **Quantum interference effects**: ADHD attention will show stronger contextual dependencies consistent with quantum probability theory

#### 5.1.2 Temporal Dynamics Predictions

1. **Fractal attentional patterns**: Temporal patterns of attention in ADHD will show self-similarity across different time scales

2. **Resonance-dependent stability**: Attentional stability will vary more dramatically based on resonance factors in ADHD than controls

3. **Recursive thought trajectories**: Thought sampling during tasks will reveal more associative, resonance-based patterns in ADHD

#### 5.1.3 Neurobiological Predictions

1. **Network co-activation**: Greater simultaneous activation of typically anti-correlated networks during attention tasks

2. **Resonance-modulated neural response**: Stronger modulation of neural activity by resonance factors in ADHD

3. **Oscillatory superposition markers**: Neural signatures of information maintenance in superposition-like states

### 5.2 Proposed Experimental Paradigms

#### 5.2.1 Attentional Superposition Measurement

**Methodology**: Adapt techniques from quantum cognition research to measure attentional superposition:

1. **Sequential versus simultaneous awareness**: Present stimuli in rapid sequence and assess awareness of multiple items

2. **Interference paradigms**: Test for quantum interference effects in attentional allocation

3. **Contextual dependency measures**: Examine how probability of attending to one stimulus depends on the context of other available stimuli

**Predictions**: Individuals with ADHD will show (1) greater simultaneous awareness of multiple stimuli, (2) stronger interference effects, and (3) more pronounced contextual dependencies compared to controls.

#### 5.2.2 Resonance Mapping

**Methodology**: Develop techniques to identify individual resonance profiles:

1. **Personalized resonance assessment**: Systematically vary stimulus properties across the five resonance dimensions while measuring attentional engagement

2. **Ecological momentary assessment**: Track attention and engagement in daily life, correlating with resonance factors

3. **Neuroimaging during resonance manipulation**: Measure neural activity while systematically varying stimulus resonance properties

**Predictions**: Resonance profiles will (1) show greater individual specificity in ADHD, (2) more strongly predict real-world attentional patterns, and (3) correlate with specific patterns of neural activation.

#### 5.2.3 Recursion Identification

**Methodology**: Apply time-series analysis to identify recursive patterns in attention:

1. **Fractal analysis**: Apply detrended fluctuation analysis to attention measures to identify self-similar patterns across time scales

2. **Recurrence quantification analysis**: Identify recursive patterns in attentional time series data

3. **Thought sampling**: Use experience sampling to map recursive trajectories in spontaneous thought

**Predictions**: ADHD attention will show (1) higher fractal dimensions, (2) more complex recurrence plots, and (3) thought patterns that follow recursive rather than hierarchical organization.

## 6. Implications and Applications

### 6.1 Educational Implications

#### 6.1.1 Resonance-Based Pedagogical Approaches

The Recursive Attention Framework suggests specific educational strategies for ADHD:

1. **Interest-based learning**: Structuring education around inherently motivating topics and activities

2. **Novelty integration**: Regularly introducing novel elements to engage recursive attention

3. **Challenge optimization**: Calibrating task difficulty to maintain optimal engagement

4. **Temporal framing**: Using urgency as a resonance factor by structuring learning with optimal deadlines

5. **Resonance-enhancing contexts**: Creating learning environments that maximize attentional resonance through multisensory engagement, movement opportunities, and personalized relevance

These approaches leverage the unique properties of recursive attention rather than attempting to force ADHD attention into neurotypical patterns.

#### 6.1.2 Assistive Technologies for Recursive Attention

Technology can be specifically designed to support recursive attention:

1. **Resonance-responsive systems**: Educational software that adapts to individual resonance profiles, shifting content and presentation to maintain engagement

2. **Attentional state detection**: Using physiological and behavioral markers to identify when attention is in superposition versus collapsed states

3. **Recursive learning paths**: Non-linear educational structures that allow exploration based on resonant connections rather than predetermined sequences

4. **Temporal flexibility**: Technologies that accommodate different temporal processing styles while maintaining educational objectives

These technologies could transform education for individuals with ADHD by working with rather than against their natural attentional patterns.

#### 6.1.3 Assessment Reconceptualization

The framework suggests fundamental changes to educational assessment:

1. **Resonance-aware evaluation**: Developing assessment methods that account for resonance factors rather than penalizing their influence

2. **Process-focused measurement**: Evaluating learning processes and developmental trajectories rather than standardized outcomes

3. **Strengths-based approaches**: Identifying and cultivating the specific cognitive advantages associated with recursive attention

4. **Multiple demonstration pathways**: Allowing knowledge and skill demonstration through diverse modalities that accommodate different attentional patterns

These assessment approaches would more accurately measure learning in individuals with recursive attention patterns.

### 6.2 Clinical Implications

#### 6.2.1 Diagnostic Refinement

The Recursive Attention Framework suggests several improvements to ADHD diagnosis:

1. **Resonance profile assessment**: Evaluating individual resonance patterns to identify ADHD subtypes based on specific resonance mechanisms

2. **Contextual performance evaluation**: Assessing performance across contexts with varying resonance properties rather than assuming consistent deficits

3. **Temporal dynamics measures**: Incorporating measures of attentional recursion and temporal processing patterns

4. **Superposition tendency assessment**: Evaluating the propensity for maintaining attention in superposition-like states

These diagnostic approaches would provide more nuanced understanding of ADHD heterogeneity and guide more targeted interventions.

#### 6.2.2 Intervention Approaches

The framework suggests novel intervention strategies:

1. **Resonance training**: Developing techniques to consciously recognize and leverage personal resonance factors

2. **Recursive pattern recognition**: Building metacognitive awareness of recursive attention patterns to enable greater self-regulation

3. **Controlled attentional collapse**: Learning techniques to intentionally collapse superposition-like states when task demands require singular focus

4. **Environmental optimization**: Creating environments that work with rather than against recursive attentional patterns

These approaches focus on working with ADHD cognitive differences rather than attempting to normalize attention.

#### 6.2.3 Medication Reconceptualization

The framework provides new perspectives on medication:

1. **Resonance modulation**: Understanding stimulant effects as modulating resonance sensitivity rather than simply normalizing attention

2. **Individualized optimal dosing**: Titrating medication based on resonance profile and attentional dynamics rather than symptom reduction alone

3. **Context-specific medication use**: Strategic medication use based on environmental demands rather than continuous administration

4. **Combined approaches**: Integrating pharmacological and non-pharmacological interventions based on resonance principles

This reconceptualization could improve medication outcomes by targeting the underlying mechanisms of recursive attention.

### 6.3 Occupational and Organizational Implications

#### 6.3.1 Workplace Design

The framework suggests specific workplace accommodations:

1. **Resonance-optimized roles**: Matching job responsibilities to individual resonance profiles

2. **Recursive workflow structures**: Designing workflows that accommodate non-linear processing and task engagement

3. **Temporal flexibility**: Implementing flexible scheduling that works with rather than against variable attentional patterns

4. **Environmental customization**: Creating work environments that enable personalized resonance optimization

These accommodations could dramatically improve occupational outcomes for individuals with ADHD.

#### 6.3.2 Organizational Diversity

The framework highlights the value of neurocognitive diversity:

1. **Complementary cognitive styles**: Leveraging the strengths of both recursive and hierarchical attention in teams

2. **Innovation potential**: Harnessing the creative advantages of recursive attention for specific organizational challenges

3. **Perspective diversity**: Utilizing different cognitive processing styles to enhance problem-solving and decision-making

4. **Inclusive leadership**: Developing leadership approaches that accommodate and value neurocognitive differences

Organizations that effectively integrate individuals with recursive attention may gain competitive advantages in innovation and adaptability.

## 7. Limitations and Future Directions

### 7.1 Theoretical Limitations

The Recursive Attention Framework has several limitations that require acknowledgment:

1. **Metaphorical use of quantum concepts**: The framework uses quantum principles as metaphors rather than claiming literal quantum effects in neural tissue

2. **Heterogeneity within ADHD**: Not all individuals with ADHD will exhibit identical patterns of recursive attention

3. **Overlap with other conditions**: Some aspects of recursive attention may be present in other neurodevelopmental and psychiatric conditions

4. **Developmental considerations**: The framework requires adaptation to account for developmental differences across the lifespan

5. **Cultural and contextual factors**: The expression of recursive attention likely varies across cultural and environmental contexts

These limitations highlight the need for further refinement and empirical validation of the framework.

### 7.2 Methodological Challenges

Several methodological challenges exist in testing the framework:

1. **Operationalizing quantum-like attention**: Developing valid measures of superposition-like attentional states

2. **Resonance quantification**: Creating reliable methods to measure individual resonance profiles

3. **Ecological validity**: Balancing controlled experimental designs with real-world relevance

4. **Individual differences**: Accounting for heterogeneity in recursive attention patterns

5. **Longitudinal assessment**: Capturing developmental trajectories of recursive attention

Addressing these challenges requires innovative methodological approaches and interdisciplinary collaboration.

### 7.3 Future Research Directions

The Recursive Attention Framework suggests several promising research directions:

#### 7.3.1 Basic Science Research

1. **Neural mechanisms**: Further investigation of the neurobiological substrates of recursive attention

2. **Developmental trajectories**: Longitudinal studies of how recursive attention evolves across the lifespan

3. **Genetic and environmental factors**: Research on the origins and development of recursive attention patterns

4. **Computational modeling**: Development of formal computational models of recursive attention dynamics

#### 7.3.2 Applied Research

1. **Educational interventions**: Testing resonance-based pedagogical approaches

2. **Workplace accommodations**: Evaluating the effectiveness of organizational adaptations

3. **Clinical interventions**: Developing and testing novel therapeutic approaches based on the framework

4. **Assistive technologies**: Creating and validating technologies that support recursive attention

#### 7.3.3 Cross-disciplinary Integration

1. **Cognitive science and quantum cognition**: Further integration with quantum probability approaches to cognition

2. **Complex systems theory**: Application of dynamical systems models to recursive attention

3. **Chronobiology**: Investigation of relationships between recursive attention and circadian rhythms

4. **Cultural neuroscience**: Exploration of cultural influences on the expression and interpretation of recursive attention

These research directions could substantially advance understanding of ADHD and inform more effective supports.

## 8. Conclusion: Paradigm Shift in Understanding ADHD

The Recursive Attention Framework represents a fundamental paradigm shift in conceptualizing ADHD—moving from a deficit-focused model to one that recognizes it as a distinct and potentially advantageous cognitive processing style. By integrating insights from quantum cognition, dynamical systems theory, and neural resonance research, this framework explains numerous ADHD phenomena that traditional models struggle to account for.

The framework's central propositions—that ADHD attention operates in superposition-like states, follows recursive rather than hierarchical patterns, responds primarily to resonance rather than importance, and achieves stability through resonance-based hyperfocus—provide a comprehensive theoretical foundation for understanding the lived experience of individuals with ADHD.

This reconceptualization has profound implications for education, clinical practice, and organizational design. By recognizing and accommodating recursive attention rather than pathologizing it, we can create environments where individuals with ADHD can thrive rather than struggle against neurotypical expectations.

Future research guided by this framework has the potential to transform our understanding of attention more broadly, challenging assumptions about optimal cognitive processing and highlighting the value of neurocognitive diversity. As the framework undergoes empirical validation and refinement, it promises to generate more effective and humane approaches to supporting individuals with recursive attention patterns, ultimately recognizing ADHD not as a disorder but as a different—and valuable—way of engaging with the world.

## References

American Psychiatric Association. (2013). Diagnostic and statistical manual of mental disorders (5th ed.). Arlington, VA: American Psychiatric Publishing.

Arnsten, A. F., & Rubia, K. (2012). Neurobiological circuits regulating attention, cognitive control, motivation, and emotion: Disruptions in neurodevelopmental psychiatric disorders. Journal of the American Academy of Child & Adolescent Psychiatry, 51(4), 356-367.

Ashinoff, B. K., & Abu-Akel, A. (2021). Hyperfocus: The forgotten frontier of attention. Psychological Research, 85(1), 1-19.

Aston-Jones, G., & Cohen, J. D. (2005). An integrative theory of locus coeruleus-norepinephrine function: Adaptive gain and optimal performance. Annual Review of Neuroscience, 28, 403-450.

Badre, D., & D'Esposito, M. (2009). Is the rostro-caudal axis of the frontal lobe hierarchical? Nature Reviews Neuroscience, 10(9), 659-669.

Blutner, R., Pothos, E. M., & Bruza, P. (2013). A quantum probability perspective on borderline vagueness. Topics in Cognitive Science, 5(4), 711-736.

Brown, T. E. (2005). Attention deficit disorder: The unfocused mind in children and adults. Yale University Press.

Bunzeck, N., & Düzel, E. (2006). Absolute coding of stimulus novelty in the human substantia nigra/VTA. Neuron, 51(3), 369-379.

Busemeyer, J. R., & Bruza, P. D. (2012). Quantum models of cognition and decision. Cambridge University Press.

Canolty, R. T., & Knight, R. T. (2010). The functional role of cross-frequency coupling. Trends in Cognitive Sciences, 14(11), 506-515.

Castellanos, F. X., & Proal, E. (2012). Large-scale brain systems in ADHD: Beyond the prefrontal–striatal model. Trends in Cognitive Sciences, 16(1), 17-26.

Castellanos, F. X., Kelly, C., & Milham, M. P. (2009). The restless brain: Attention-deficit hyperactivity disorder, resting-state functional connectivity, and intrasubject variability. Canadian Journal of Psychiatry, 54(10), 665-672.

Castellanos, F. X., Margulies, D. S., Kelly, C., Uddin, L. Q., Ghaffari, M., Kirsch, A., ... & Milham, M. P. (2008). Cingulate-precuneus interactions: A new locus of dysfunction in adult attention-deficit/hyperactivity disorder. Biological Psychiatry, 63(3), 332-337.

Castellanos, F. X., Sonuga-Barke, E. J., Scheres, A., Di Martino, A., Hyde, C., & Walters, J. R. (2005). Varieties of attention-deficit/hyperactivity disorder-related intra-individual variability. Biological Psychiatry, 57(11), 1416-1423.

Cavanagh, J. F., & Frank, M. J. (2014). Frontal theta as a mechanism for cognitive control. Trends in Cognitive Sciences, 18(8), 414-421.

Chomsky, N. (1957). Syntactic structures. The Hague: Mouton.

Corballis, M. C. (2011). The recursive mind: The origins of human language, thought, and civilization. Princeton University Press.

Cortese, S., Kelly, C., Chabernaud, C., Proal, E., Di Martino, A., Milham, M. P., & Castellanos, F. X. (2012). Toward systems neuroscience of ADHD: A meta-analysis of 55 fMRI studies. American Journal of Psychiatry, 169(10), 1038-1055.

Dekkers, T. J., Popma, A., Agelink van Rentergem, J. A., Bexkens, A., & Huizenga, H. M. (2017). Risky decision making in attention-deficit/hyperactivity disorder: A meta-regression analysis. Clinical Psychology Review, 56, 1-16.

Del Campo, N., Chamberlain, S. R., Sahakian, B. J., & Robbins, T. W. (2011). The roles of dopamine and noradrenaline in the pathophysiology and treatment of attention-deficit/hyperactivity disorder. Biological Psychiatry, 69(12), e145-e157.

Delisle, J., & Delisle, J. (2014). Bright minds, poor grades: Understanding and motivating your underachieving child. Sourcebooks, Inc.

Engel, A. K., Fries, P., & Singer, W. (2001). Dynamic predictions: Oscillations and synchrony in top-down processing. Nature Reviews Neuroscience, 2(10), 704-716.

Forster, S., Robertson, D. J., Jennings, A., Asherson, P., & Lavie, N. (2014). Plugging the attention deficit: Perceptual load counters increased distraction in ADHD. Neuropsychology, 28(1), 91-97.

Fox, M. D., Snyder, A. Z., Vincent, J. L., Corbetta, M., Van Essen, D. C., & Raichle, M. E. (2005). The human brain is intrinsically organized into dynamic, anticorrelated functional networks. Proceedings of the National Academy of Sciences, 102(27), 9673-9678.

Fries, P. (2009). Neuronal gamma-band synchronization as a fundamental process in cortical computation. Annual Review of Neuroscience, 32, 209-224.

Fries, P. (2015). Rhythms for cognition: Communication through coherence. Neuron, 88(1), 220-235.

Grossman, E. S., Hoffman, Y. S., Berger, I., & Zivotofsky, A. Z. (2015). Beating their chests: University students with ADHD demonstrate greater attentional abilities on an inattentional blindness paradigm. Neuropsychology, 29(6), 882-887.

Haenlein, M., & Caul, W. F. (1987). Attention deficit disorder with hyperactivity: A specific hypothesis of reward dysfunction. Journal of the American Academy of Child & Adolescent Psychiatry, 26(3), 356-362.

Hallowell, E. M., & Ratey, J. J. (2011). Driven to distraction: Recognizing and coping with attention deficit disorder from childhood through adulthood. Anchor Books.

Hauser, M. D., Chomsky, N., & Fitch, W. T. (2002). The faculty of language: What is it, who has it, and how did it evolve? Science, 298(5598), 1569-1579.

Hofstadter, D. R. (1979). Gödel, Escher, Bach: An eternal golden braid. Basic Books.

Hoogman, M., Bralten, J., Hibar, D. P., Mennes, M., Zwiers, M. P., Schweren, L. S., ... & Franke, B. (2017). Subcortical brain volume differences in participants with attention deficit hyperactivity disorder in children and adults: A cross-sectional mega-analysis. The Lancet Psychiatry, 4(4), 310-319.

Hoogman, M., Stolte, M., Baas, M., & Kroesbergen, E. (2020). Creativity and ADHD: A review of behavioral studies, the effect of psychostimulants and neural underpinnings. Neuroscience & Biobehavioral Reviews, 119, 66-85.

Hupfeld, K. E., Abagis, T. R., & Shah, P. (2018). Living "in the zone": Hyperfocus in adult ADHD. ADHD Attention Deficit and Hyperactivity Disorders, 11(2), 191-208.

Jensen, O., & Mazaheri, A. (2010). Shaping functional architecture by oscillatory alpha activity: Gating by inhibition. Frontiers in Human Neuroscience, 4, 186.

Koechlin, E., Ody, C., & Kouneiher, F. (2003). The architecture of cognitive control in the human prefrontal cortex. Science, 302(5648), 1181-1185.

Kofler, M. J., Rapport, M. D., Sarver, D. E., Raiker, J. S., Orban, S. A., Friedman, L. M., & Kolomeyer, E. G. (2013). Reaction time variability in ADHD: A meta-analytic review of 319 studies. Clinical Psychology Review, 33(6), 795-811.

Kreither, J., Lopez-Calderon, J., Leonard, C. J., Robinson, B. M., Ruffle, A., Hahn, B., ... & Luck, S. J. (2017). Electrophysiological evidence for hyperfocusing of spatial attention in schizophrenia. Journal of Neuroscience, 37(16), 3813-3823.

Lakatos, P., Karmos, G., Mehta, A. D., Ulbert, I., & Schroeder, C. E. (2008). Entrainment of neuronal oscillations as a mechanism of attentional selection. Science, 320(5872), 110-113.

Lenartowicz, A., Mazaheri, A., Jensen, O., & Loo, S. K. (2018). Aberrant modulation of brain oscillatory activity and attentional impairment in attention-deficit/hyperactivity disorder. Biological Psychiatry: Cognitive Neuroscience and Neuroimaging, 3(1), 19-29.

Li, D., Sham, P. C., Owen, M. J., & He, L. (2006). Meta-analysis shows significant association between dopamine system genes and attention deficit hyperactivity disorder (ADHD). Human Molecular Genetics, 15(14), 2276-2284.

Liddle, E. B., Hollis, C., Batty, M. J., Groom, M. J., Totman, J. J., Liotti, M., ... & Liddle, P. F. (2011). Task‐related default mode network modulation and inhibitory control in ADHD: Effects of motivation and methylphenidate. Journal of Child Psychology and Psychiatry, 52(7), 761-771.

Loo, S. K., & Makeig, S. (2012). Clinical utility of EEG in attention-deficit/hyperactivity disorder: A research update. Neurotherapeutics, 9(3), 569-587.

Mazaheri, A., Coffey-Corina, S., Mangun, G. R., Bekker, E. M., Berry, A. S., & Corbett, B. A. (2010). Functional disconnection of frontal cortex and visual cortex in attention-deficit/hyperactivity disorder. Biological Psychiatry, 67(7), 617-623.

Mazaheri, A., Fassbender, C., Coffey-Corina, S., Hartanto, T. A., Schweitzer, J. B., & Mangun, G. R. (2014). Differential oscillatory electroencephalogram between attention-deficit/hyperactivity disorder subtypes and typically developing adolescents. Biological Psychiatry, 76(5), 422-429.

Miller, E. K., & Cohen, J. D. (2001). An integrative theory of prefrontal cortex function. Annual Review of Neuroscience, 24(1), 167-202.

Mowinckel, A. M., Alnæs, D., Pedersen, M. L., Ziegler, S., Fredriksen, M., Kaufmann, T., ... & Biele, G. (2017). Increased default-mode variability is related to reduced task-performance and is evident in adults with ADHD. NeuroImage: Clinical, 16, 369-382.

Norman, L. J., Carlisi, C., Lukito, S., Hart, H., Mataix-Cols, D., Radua, J., & Rubia, K. (2016). Structural and functional brain abnormalities in attention-deficit/hyperactivity disorder and obsessive-compulsive disorder: A comparative meta-analysis. JAMA Psychiatry, 73(8), 815-825.

Plichta, M. M., & Scheres, A. (2014). Ventral–striatal responsiveness during reward anticipation in ADHD and its relation to trait impulsivity in the healthy population: A meta-analytic review of the fMRI literature. Neuroscience & Biobehavioral Reviews, 38, 125-134.

Posner, J., Nagel, B. J., Maia, T. V., Mechling, A., Oh, M., Wang, Z., & Peterson, B. S. (2011). Abnormal amygdalar activation and connectivity in adolescents with attention-deficit/hyperactivity disorder. Journal of the American Academy of Child & Adolescent Psychiatry, 50(8), 828-837.

Pothos, E. M., & Busemeyer, J. R. (2009). A quantum probability explanation for violations of 'rational' decision theory. Proceedings of the Royal Society B: Biological Sciences, 276(1665), 2171-2178.

Pothos, E. M., & Busemeyer, J. R. (2013). Can quantum probability provide a new direction for cognitive modeling? Behavioral and Brain Sciences, 36(3), 255-274.

Premack, D., & Woodruff, G. (1978). Does the chimpanzee have a theory of mind? Behavioral and Brain Sciences, 1(4), 515-526.

Raichle, M. E., MacLeod, A. M., Snyder, A. Z., Powers, W. J., Gusnard, D. A., & Shulman, G. L. (2001). A default mode of brain function. Proceedings of the National Academy of Sciences, 98(2), 676-682.

Roberts, B. A., Martel, M. M., & Nigg, J. T. (2017). Are there executive dysfunction subtypes within ADHD? Journal of Attention Disorders, 21(4), 284-293.

Rubia, K., Smith, A. B., Halari, R., Matsukura, F., Mohammad, M., Taylor, E., & Brammer, M. J. (2009). Disorder-specific dissociation of orbitofrontal dysfunction in boys with pure conduct disorder during reward and ventrolateral prefrontal dysfunction in boys with pure ADHD during sustained attention. American Journal of Psychiatry, 166(1), 83-94.

Schroeder, C. E., & Lakatos, P. (2009). Low-frequency neuronal oscillations as instruments of sensory selection. Trends in Neurosciences, 32(1), 9-18.

Schultz, W. (2002). Getting formal with dopamine and reward. Neuron, 36(2), 241-263.

Sedgwick, J. A., Merwood, A., & Asherson, P. (2019). The positive aspects of attention deficit hyperactivity disorder: A qualitative investigation of successful adults with ADHD. ADHD Attention Deficit and Hyperactivity Disorders, 11(3), 241-253.

Shaffer, D., Gould, M. S., Brasic, J., Ambrosini, P., Fisher, P., Bird, H., & Aluwahlia, S. (2001). A children's global assessment scale (CGAS). Archives of General Psychiatry, 58(11), 1064-1069.

Shaw, P., Stringaris, A., Nigg, J., & Leibenluft, E. (2014). Emotion dysregulation in attention deficit hyperactivity disorder. American Journal of Psychiatry, 171(3), 276-293.

Sidlauskaite, J., Sonuga-Barke, E., Roeyers, H., & Wiersema, J. R. (2016). Altered intrinsic organisation of brain networks implicated in attentional processes in adult attention-deficit/hyperactivity disorder: A resting-state study of attention, default mode and salience network connectivity. European Archives of Psychiatry and Clinical Neuroscience, 266(4), 349-357.

Sikström, S., & Söderlund, G. (2007). Stimulus-dependent dopamine release in attention-deficit/hyperactivity disorder. Psychological Review, 114(4), 1047-1075.

Skirrow, C., McLoughlin, G., Banaschewski, T., Brandeis, D., Kuntsi, J., & Asherson, P. (2015). Normalisation of frontal theta activity following methylphenidate treatment in adult attention-deficit/hyperactivity disorder. European Neuropsychopharmacology, 25(1), 85-94.

Sonuga-Barke, E. J., & Castellanos, F. X. (2007). Spontaneous attentional fluctuations in impaired states and pathological conditions: A neurobiological hypothesis. Neuroscience & Biobehavioral Reviews, 31(7), 977-986.

Spencer, T. J., Brown, A., Seidman, L. J., Valera, E. M., Makris, N., Lomedico, A., ... & Biederman, J. (2013). Effect of psychostimulants on brain structure and function in ADHD: A qualitative literature review of magnetic resonance imaging-based neuroimaging studies. The Journal of Clinical Psychiatry, 74(9), 902-917.

Spreng, R. N., Stevens, W. D., Chamberlain, J. P., Gilmore, A. W., & Schacter, D. L. (2010). Default network activity, coupled with the frontoparietal control network, supports goal-directed cognition. Neuroimage, 53(1), 303-317.

Sripada, C., Kessler, D., & Angstadt, M. (2014). Lag in maturation of the brain's intrinsic functional architecture in attention-deficit/hyperactivity disorder. Proceedings of the National Academy of Sciences, 111(39), 14259-14264.

Still, G. F. (1902). Some abnormal psychical conditions in children. The Lancet, 159(4102), 1008-1012.

Swanson, J. M., Volkow, N. D., Newcorn, J., Casey, B. J., Moyzis, R., Grandy, D., & Posner, M. (2011). Attention deficit hyperactivity disorder. In Encyclopedia of Neuroscience (pp. 249-251). Elsevier Ltd.

Szekely, E., Sudre, G. P., Sharp, W., Leibenluft, E., & Shaw, P. (2017). Defining the neural substrate of the adult outcome of childhood ADHD: A multimodal neuroimaging study of response inhibition. American Journal of Psychiatry, 174(9), 867-876.

Trueblood, J. S., & Busemeyer, J. R. (2011). A quantum probability account of order effects in inference. Cognitive Science, 35(8), 1518-1552.

Uddin, L. Q., Kelly, A. M., Biswal, B. B., Margulies, D. S., Shehzad, Z., Shaw, D., ... & Milham, M. P. (2008). Network homogeneity reveals decreased integrity of default-mode network in ADHD. Journal of Neuroscience Methods, 169(1), 249-254.

Volkow, N. D., Wang, G. J., Kollins, S. H., Wigal, T. L., Newcorn, J. H., Telang, F., ... & Swanson, J. M. (2009). Evaluating dopamine reward pathway in ADHD: Clinical implications. JAMA, 302(10), 1084-1091.

Volkow, N. D., Wang, G. J., Newcorn, J. H., Kollins, S. H., Wigal, T. L., Telang, F., ... & Swanson, J. M. (2011). Motivation deficit in ADHD is associated with dysfunction of the dopamine reward pathway. Molecular Psychiatry, 16(11), 1147-1154.

Wang, Z., Busemeyer, J. R., Atmanspacher, H., & Pothos, E. M. (2018). The potential of using quantum theory to build models of cognition. Topics in Cognitive Science, 10(3), 672-688.

Watkins, E. R. (2008). Constructive and unconstructive repetitive thought. Psychological Bulletin, 134(2), 163-206.

White, H. A., & Shah, P. (2006). Uninhibited imaginations: Creativity in adults with attention-deficit/hyperactivity disorder. Personality and Individual Differences, 40(6), 1121-1131.
